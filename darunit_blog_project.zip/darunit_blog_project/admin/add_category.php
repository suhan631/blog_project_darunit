<?php
$view = "add_category";
include_once("template.php");
?>