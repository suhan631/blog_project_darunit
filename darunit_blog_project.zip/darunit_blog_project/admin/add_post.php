<?php
$view = "add_post";
include_once("template.php");
?>