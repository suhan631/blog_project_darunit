<?php
$view = "dashboard";
include_once("template.php");
?>