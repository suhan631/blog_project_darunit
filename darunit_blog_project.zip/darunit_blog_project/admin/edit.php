<?php
$view = "edit";
include_once("template.php");
?>