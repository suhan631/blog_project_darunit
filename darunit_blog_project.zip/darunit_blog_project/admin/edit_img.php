<?php
$view = "edit_img";
include_once("template.php");
?>