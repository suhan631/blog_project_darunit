<?php
$view = "edit_post";
include_once("template.php");
?>