<?php
$view = "manage_category";
include_once("template.php");
?>