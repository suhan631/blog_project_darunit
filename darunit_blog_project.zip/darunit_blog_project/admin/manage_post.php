<?php
$view = "manage_post";
include_once("template.php");
?>