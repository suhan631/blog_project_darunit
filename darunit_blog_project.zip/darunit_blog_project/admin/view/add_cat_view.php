<?php
$obj = new adminBlog();
if(isset($_POST['add_cat'])){
   $return_msg = $obj->add_category($_POST);
}
?>


<h2>Add category page</h2>
<?php
if(isset($return_msg)){
     
echo '<script>alert("Category added successfully!")</script>';


}
?>
<form action="" method="POST">
    <div class="form-group">
         <label class="mb-1" for="cat_name">Category Name</label>
         <input name="cat_name" class="form-control py-4" id="cat_name" type="text"/>
    </div>
    <div class="form-group">
         <label class="mb-1" for="cat_name">Category Description</label>
         <input name="cat_des" class="form-control py-4" id="cat_des" type="text"/>
    </div>
    <input type="submit" value="Add Category" class="form control btn btn-block btn-primary" name="add_cat">
</form>