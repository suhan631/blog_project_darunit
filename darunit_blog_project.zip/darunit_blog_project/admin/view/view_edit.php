<?php

if(isset($_GET['status'])){
  if($_GET['status']='edit'){
    $id = $_GET['id'];
    $return_data = $obj->display_data_by_id($id);
  }
}
if(isset($_POST['edit_btn'])){
   $msg=$obj->update_data($_POST);
   if(isset($_GET['status'])){
    if($_GET['status']='edit'){
      $id = $_GET['id'];
      $return_data = $obj->display_data_by_id($id);
    }
  }
}
if(isset($msg)){
    echo $msg;
    
}
?>
<br>
<a class="btn btn-primary" href="manage_category.php">Back to Manage Category Page</a>

<form action="" method="POST">
    <div class="form-group">
         <label class="mb-1" for="cat_name">Category Name</label>
         <input name="u_cat_name" class="form-control py-4" id="cat_name" value="<?php if(isset($return_data)){echo $return_data['cat_name']; }?>" type="text"/>
    </div>
    <div class="form-group">
         <label class="mb-1" for="cat_name">Category Description</label>
         <input name="u_cat_des" class="form-control py-4" id="cat_des" value="<?php if(isset($return_data)){echo $return_data['cat_des']; }?>" type="text"/>
    </div>
    <input type="hidden" name="cat_id" value="<?php echo $return_data['cat_id'];?>">
    <input type="submit" value="Update Category" class="form control btn btn-block btn-primary" name="edit_btn">
</form>