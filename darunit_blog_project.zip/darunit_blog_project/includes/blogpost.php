<?php 
    $post_s = $obj->display_post_publish();
?>
<div class="col-lg-8">
            <div class="all-blog-posts">
              <div class="row">
              <?php while($postdata=mysqli_fetch_assoc($post_s)) { ?>
                <div class="col-lg-12">
                  <div class="blog-post">
                    <div class="blog-thumb">
                    <img height="300px" width="300px" src="upload/<?php echo $postdata['post_img'] ?>">
                    
                    </div>
                    <div class="down-content">
                    
                      <a href="single_post.php?view=postview&&id=<?php echo $postdata['post_id'] ?>">

                      <h3><?php echo $postdata['post_title'] ?></h3>
                      </a>
                      
                      <ul class="post-info">
                        <li><a href="#"><?php echo $postdata['post_author']; ?></a></li>
                        <li><a href="#"><?php echo $postdata['post_date']; ?></a></li>
                        <li><a href="#"><?php echo $postdata['post_comment_count']; ?> Comments</a></li>
                      </ul>
                      <p><?php echo $postdata['post_content'] ?></p>
                      <div class="post-options">
                        <div class="row">
                          <div class="col-6">
                            <ul class="post-tags">
                              <li><i class="fa fa-tags"></i></li>
                              <li><a href="#">Beauty</a>,</li>
                              <li><a href="#">Nature</a></li>
                            </ul>
                          </div>
                          <div class="col-6">
                            <ul class="post-share">
                              <li><i class="fa fa-share-alt"></i></li>
                              <li><a href="#">Facebook</a>,</li>
                              <li><a href="#"> Twitter</a></li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
               <?php } ?>
              </div>
             
            </div>
          </div>